<?php
session_start();
//ATUR UKURAN GAMBAR
						define("THE_SIZE", "4096");
	$folder = 'uploads/';
	
	$targ_w = 720;
	$targ_h = 300;
	
	$ratio = $targ_w / $targ_h;
	
	if( isset($_POST['crop']))
	 {	
		$src = imagecreatefromjpeg($folder.$_SESSION['bakalfileGambar']);
	
		$tmp = imagecreatetruecolor($targ_w, $targ_h);
		imagecopyresampled($tmp, $src, 0,0,$_POST['x'],$_POST['y'],$targ_w,$targ_h,$_POST['w'],$_POST['h']);
		imagejpeg($tmp, $folder.'t_'.$_SESSION['bakalfileGambar'],100);
		
		imagedestroy($tmp);
		imagedestroy($src);
		
	}
?>
	<script type="text/javascript" src="includes/jquery-1.6.2.min.js"></script>
	<script type="text/javascript" src="includes/jquery.Jcrop.min.js"></script>
	<link rel="stylesheet" href="includes/jquery.Jcrop.css" type="text/css" />

	<script type="text/javascript">
		$(function(){
			$('#cropbox').Jcrop({
				aspectRatio: <?php echo $ratio?>,
				setSelect: [0,<?php echo $targ_w.','.$targ_h;?>,0],
				allowSelect: true,
				allowMove: true,
				allowResize: true,
				minSize: [610, 292],
				onSelect: updateCoords,
				onChange: updateCoords
			});
		});
		
		function updateCoords(c) {
			showPreview(c);
			$("#x").val(c.x);
			$("#y").val(c.y);
			$("#w").val(c.w);
			$("#h").val(c.h);
		}
		function showPreview(coords) {
			var rx = <?php echo $targ_w;?> / coords.w;
			var ry = <?php echo $targ_h;?> / coords.h;
		}
		
	</script>

<?php



			//START CLASS BUAT INPUT BERITA	
			
				if(!isset($_POST['fSubmitBerita'])) 
				{
					echo "<fieldset class='berita'>";


					if(!isset($_POST['formuploadGambar'])) 
					{
						if(isset($_POST['crop'])) 
							//TAMPILKAN GAMBAR HASIL CROP

							echo "<div align='center'><a href='#' class='admimage'><img src='".$folder.'t_'.$_SESSION['bakalfileGambar']."' /></a></div>";
						else {

							//UPLOAD GAMBAR
							echo "<form method='post' name='InputBerita' action='' enctype='multipart/form-data'>";
							echo "<div align='center' style='padding:10px 0;'>Disarankan untuk mengunggah gambar dengan resolusi maksimum ".THE_SIZE." pixel.</div>";
							echo "<div align='center'><hr size='1' /><strong>Masukkan Gambar :</strong><input type='file' name='uploadGambar' class='inp' />&nbsp;";
							echo "<input type='submit' name='formuploadGambar' value='Upload' class='submit' /></div>";
							echo "</form>";
						}
					} 
					else 

					{
						
							
						define ("MAX_SIZE","800"); 
						define ("WIDTH","130"); 
						define ("HEIGHT","130");
		
						$uploadGambar=$_FILES['uploadGambar']['name'];
						
						if(empty($uploadGambar)) 
						{
							//BELUM UPLOAD
							echo "<div align='center' class='alert'>Anda belum memasukkan gambar!</div>";
							echo "<META HTTP-EQUIV = 'Refresh' Content = '1; URL = ?page=Berita&act=Input'>";
						} else 
						{
							//SUDAH UPLOAD GAMBAR
							 
								//EXT BENER
								$size=getimagesize($_FILES['uploadGambar']['tmp_name']);
								$sizekb=filesize($_FILES['uploadGambar']['tmp_name']);
				
								if ($sizekb > MAX_SIZE*THE_SIZE) 
								{
								
									//UKURAN KEGEDEAN
									echo "<div align='center' class='alert'>Ukuran file terlalu besar!</div>";
									echo "<META HTTP-EQUIV = 'Refresh' Content = '2; URL = ?page=Berita&act=Input'>";
								} else 
								{
									//UKURAN PAS
									$image_name=time().'.jpg';//$extension;
									
									$newname=$folder.$image_name;
									
									$copied = copy($_FILES['uploadGambar']['tmp_name'], $newname);
								
									if (!$copied) 
									{
										//GA KE COPY
										echo "<div align='center'>gagal mengambil file!</div>";
										echo "<META HTTP-EQUIV = 'Refresh' Content = '2; URL = ?page=Berita&act=Input'>";
									} else 
									{
										//BERHASIL DI COPY


										 $thumbWidth = 200; // can change it to whatever required
    $thumbHeight = 200; // can change it to whatever required

    $img = imagecreatefromstring(file_get_contents($folder.$image_name));
    $imgWidth = imagesx($img);
    $imgHeight = imagesy($img);

    $imgStart_x = 0;
    $imgStart_y = 0;
    $imgEnd_x = $imgWidth;
    $imgEnd_y = $imgHeight;

    if($imgWidth > $imgHeight){
        $diff = $imgWidth - $imgHeight;
        $imgStart_x = $diff / 2;
        $imgEnd_x = $imgWidth - $diff;
    }else{
        $diff = $imgHeight - $imgWidth;
        $imgEnd_y = $imgHeight - $diff;
    }

    $dest = imagecreatetruecolor($thumbHeight,$thumbHeight);
    imagecopyresized($dest, $img, 0, 0, $imgStart_x, $imgStart_y, $thumbWidth, $thumbHeight, $imgEnd_x, $imgEnd_y);
   
     imagejpeg($dest, $folder.time().'_thumb'.'.jpeg',100);

     imagePNG($dest,$folder.time().'_thumb'.'.png');


 
									}
																	
									echo "<div align='center'>
									<img src='".$newname."' align='center' id='cropbox' /></div>";

									echo '<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
										<p align="center">
											<input type="hidden" id="x" name="x" />
											<input type="hidden" id="y" name="y" />
											<input type="hidden" id="w" name="w" />
											<input type="hidden" id="h" name="h" /><br />
											<input type="submit" id="submit" class="submit" name="crop" value="Pangkas!" />
										</p>
									</form>';
									//Bikin Session Gambar	
							$_SESSION['bakalfileGambar']=$image_name;
								}
							 
						}
					}
					echo "</fieldset>";
					
					/** -----------------------------------------o(|)o----------------------------------------- **/
					
					
					//getEditorHalf();
					
					echo "<fieldset class='berita full'>";
					echo "<br />
					<form method='post' action='' name='InputBerita'>";
					echo "<b>Judul:</b><br />";
					echo "<input type='text' class='inp' name='fJudul' size='100' /><br /><br />";
					 			
					echo "<hr size='1' />";
				 
					echo "<input type='submit' name='fSubmitBerita' value=' Save ' class='submit' />";
					echo "<input type='button' name='cancel' value='Cancel' class='submit' onclick='window.history.back()' /><br /><br />";
					echo "</form>";
					echo "</fieldset>";
					
				} else

				{
					if(!isset($_SESSION['bakalfileGambar'])) {

					$image="";}
					else {
					//NGAMBIL VAR GAMBAR
					$image=$_SESSION['bakalfileGambar'];
					$jdl=ucwords($_POST['fJudul']);
					
					
					echo "<fieldset class='berita'>";
					//NGECEK JUDUL AMA ISI BERITA
					if(empty($image)) 
					{
						echo "<div align='center' class='alert'>Anda belum memasukkan gambar!</div>";
						echo "<META HTTP-EQUIV = 'Refresh' Content = '1; URL = index.php'>";
					} else 
					{
						echo '<div align="center">';
						echo '<h1 align="center">'.$jdl.'</h1>';

						echo '<h1 align="center"><img src="'.$folder.'t_'.$image.'" ></h1><br>';
						echo '</div>';

						echo "<META HTTP-EQUIV = 'Refresh' Content = '3; URL = index.php'>";


					}
					//BUANG SESSION GAMBAR
					unset($_SESSION['bakalfileGambar']);
					echo "</fieldset>";}
				}


			
        
			 
           
?>